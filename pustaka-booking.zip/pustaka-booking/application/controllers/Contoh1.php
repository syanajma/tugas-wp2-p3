<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h1>Perkenalkan</h1>";
        echo "Nama saya Tasya Najmah Zahirah, saya tinggal di jakarta selatan, Saya memiliki hobi menonton";
    }
}